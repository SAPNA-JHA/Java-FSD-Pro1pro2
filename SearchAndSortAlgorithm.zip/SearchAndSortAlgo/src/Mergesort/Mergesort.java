package Mergesort;

public class Mergesort {
	 public static void mergeSort(int[] arr) {
	        if (arr.length <= 1) {
	            return; // Array is already sorted
	        }

	        // Split the array into two halves
	        int mid = arr.length / 2;
	        int[] left = new int[mid];
	        int[] right = new int[arr.length - mid];

	        // Populate the left and right arrays
	        for (int i = 0; i < mid; i++) {
	            left[i] = arr[i];
	        }
	        for (int i = mid; i < arr.length; i++) {
	            right[i - mid] = arr[i];
	        }

	        // Recursively sort the left and right halves
	        mergeSort(left);
	        mergeSort(right);

	        // Merge the sorted halves
	        merge(arr, left, right);
	 }
	        private static void merge(int[] result, int[] left, int[] right) {
	            int i = 0, j = 0, k = 0;

	            while (i < left.length && j < right.length) {
	                if (left[i] <= right[j]) {
	                    result[k++] = left[i++];
	                } else {
	                    result[k++] = right[j++];
	                }
	            }

	            // Copy remaining elements of left and right arrays, if any
	            while (i < left.length) {
	                result[k++] = left[i++];
	            }
	            while (j < right.length) {
	                result[k++] = right[j++];
	            }
	        }

	public static void main(String[] args) {
		int[] arr = {2, 11, 3, 15, 6, 27};

        System.out.println("Original Array:");
        printArray(arr);

        mergeSort(arr);

        System.out.println("\nSorted Array:");
        printArray(arr);
    }

    private static void printArray(int[] arr) {
        for (int value : arr) {
            System.out.print(value + " ");
        }
        System.out.println();

	}

}
