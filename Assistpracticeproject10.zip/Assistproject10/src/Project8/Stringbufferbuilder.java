package Project8;

public class Stringbufferbuilder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="Jenny deol";
		
		 // Convert the string to StringBuffer
        StringBuffer sB = new StringBuffer(str);
        
     // Convert the string to StringBuilder
        StringBuilder SB = new StringBuilder(str);

     // Display the original string
        System.out.println("String: " + str);
        
     // Display the StringBuffer version
        System.out.println("StringBuffer: " + sB.toString());

        // Display the StringBuilder version
        System.out.println("StringBuilder: " + SB.toString());
	}

}
