/**
 * 
 */
/**
 * 
 */
module Assistproject10 {
}