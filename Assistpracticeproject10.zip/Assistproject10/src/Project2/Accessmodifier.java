package Project2;

public class Accessmodifier {
		void display() 
	    { 
	        System.out.println("defalut access specifier"); 
	    } 
		private void display1() 
	    { 
	        System.out.println("private access specifier"); 
	    }
		protected void display2() 
	    { 
	        System.out.println("protected access specifier"); 
	    } 
		public void display3() 
	    { 
	        System.out.println("Public Access Specifiers"); 
	    } 
	public static void main(String[] args) {
			
		 Accessmodifier  obj = new  Accessmodifier (); 
	        obj.display(); 
	        obj.display1(); 

	        obj.display2(); 
	        obj.display3(); 


	}

}
