package project5;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.Map;

public class IOcollection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<String> arrayList = new ArrayList<>();
        arrayList.add("sapna");
        arrayList.add("srishti");
        arrayList.add("charles");

        System.out.println("ArrayList elements:");
        for (String name : arrayList) {
            System.out.println(name);
        }

        // Verify HashSet implementation
        Set<Integer> hashSet = new HashSet<>();
        hashSet.add(30);
        hashSet.add(20);
        hashSet.add(60);

        System.out.println("\nHashSet elements:");
        for (int num : hashSet) {
            System.out.println(num);
        }

        // Verify HashMap implementation
        Map<String, Integer> hashMap = new HashMap<>();
        hashMap.put("One", 1);
        hashMap.put("Two", 2);
        hashMap.put("Three", 3);

        System.out.println("\nHashMap elements:");
        for (Map.Entry<String, Integer> entry : hashMap.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

	}

}
