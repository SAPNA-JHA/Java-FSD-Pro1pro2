package Project1;

public class Typecasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				//implicit typecasting
				
				int x=6;
				double y=x;
				System.out.println(y);
				
				//Explicit typecasting
				
				double myDouble=7.876;
				int myInt= (int)myDouble;
				
				System.out.println(myDouble);
				System.out.println(myInt);
				

   }

}

