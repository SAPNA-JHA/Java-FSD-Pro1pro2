package Project4;

public class IOconstructortypes {
    // Default Constructor (no parameters)
    public IOconstructortypes() {
        System.out.println("Default Constructor called.");
    }

    // Parameterized Constructor with one parameter
    public IOconstructortypes(String message) {
        System.out.println("Parameterized Constructor with message: " + message);
    }

    // Overloaded Constructor with two parameters
    public IOconstructortypes(int num1, int num2) {
        int sum = num1 + num2;
        System.out.println("Overloaded Constructor with sum: " + sum);
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Creating objects using different constructors
		 IOconstructortypes defaultConstructorObj = new IOconstructortypes();
		 IOconstructortypes paramConstructorObj = new IOconstructortypes("Hello,jenny!");
		 IOconstructortypes overloadedConstructorObj = new IOconstructortypes(5, 9);

	}

}
