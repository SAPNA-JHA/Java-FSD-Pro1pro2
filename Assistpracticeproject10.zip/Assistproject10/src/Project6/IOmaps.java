package Project6;
import java.util.*;


public class IOmaps {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// HashMap
        Map<String, Integer> hashMap = new HashMap<>();
        hashMap.put("sapna", 75);
        hashMap.put("jenny", 80);
        hashMap.put("chiku", 55);
        
     // LinkedHashMap
        Map<String, Integer> linkedHashMap = new LinkedHashMap<>();
        linkedHashMap.put("One", 1);
        linkedHashMap.put("Two", 2);
        linkedHashMap.put("Three", 3);
        
        // TreeMap
        Map<String, Integer> treeMap = new TreeMap<>();
        treeMap.put("Mon", 1);
        treeMap.put("Tue", 2);
        treeMap.put("Wed", 3);
		
        
        // Print HashMap
        System.out.println("HashMap:");
        for (String key : hashMap.keySet()) {
            System.out.println(key + " -> " + hashMap.get(key));
        }

        // Print LinkedHashMap
        System.out.println("\nLinkedHashMap:");
        for (String key : linkedHashMap.keySet()) {
            System.out.println(key + " -> " + linkedHashMap.get(key));
        }

        // Print TreeMap
        System.out.println("\nTreeMap:");
        for (String key : treeMap.keySet()) {
            System.out.println(key + " -> " + treeMap.get(key));
        }

	}

}
