package Project3;

public class Implementationofmethod {
	public void printMessage() {
        System.out.println("Hello, Sapna");
    }
	
    public int add(int x, int y) {
        return x + y;
    }

    // Method with a parameter and no return value (void)
    public void greetUser(String name) {
    	  System.out.println("Hello, " + name);
    }


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Implementationofmethod IM = new Implementationofmethod();

        // Calling a method with no parameters and no return value
        IM.printMessage();

        // Calling a method with parameters and return value
        int result = IM.add(5, 3);
        System.out.println("Add method: " + result);

        // Calling a method with a parameter and no return value
        IM.greetUser("jenny");
    }
}
