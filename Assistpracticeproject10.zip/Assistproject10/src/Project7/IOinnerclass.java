package Project7;

public class IOinnerclass {
	
	// Inner class
    public class InnerClass {
        // Inner class members
        private int innerField = 20;
        
     // Constructor for the inner class
        public InnerClass() {
            System.out.println("Inner class");
        }
        
        // Inner class method
        public void innerMethod() {
            System.out.println("class method ");
        }
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Create an instance of the inner class
		IOinnerclass outerObj = new IOinnerclass();
		IOinnerclass.InnerClass innerObj = outerObj.new InnerClass();

        // Accessing inner class members
        innerObj.innerMethod();


	}

}
