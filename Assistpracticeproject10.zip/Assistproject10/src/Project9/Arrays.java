package Project9;

public class Arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//single-dimensional array
				int a[]= {23,59,30,68,70};
				for(int i=0;i<5;i++) {
				System.out.println("Elements of array a: "+a[i]);
				}
				//multidimensional array
				int[][] b = {
				 {7, 7, 8, 15}, 
				 {4, 7, 9}};
				 
				 System.out.println("\nLength of row 1: " + b[0].length);

	}

}
