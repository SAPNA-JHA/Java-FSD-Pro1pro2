/**
 * 
 */
/**
 * 
 */
module Corejavaassistproject9 {
}