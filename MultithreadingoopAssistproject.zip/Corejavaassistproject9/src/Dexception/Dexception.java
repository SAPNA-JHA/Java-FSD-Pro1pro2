package Dexception;
import java.util.Scanner;

public class Dexception {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Enter a numerator: ");
            int numerator = scanner.nextInt();

            System.out.print("Enter a denominator: ");
            int denominator = scanner.nextInt();

            int result = divide(numerator, denominator);
            System.out.println("Result of division: " + result);
        } 
        catch (ArithmeticException e) {
            System.err.println("Error: Division by zero is not allowed.");
        }
        catch (java.util.InputMismatchException e) {
            System.err.println("Error: Please enter valid integers.");
        }
        finally {
            // The finally block always runs, whether an exception occurs or not.
            System.out.println(" result show.");
            scanner.close();
        }
        System.out.println("continues.");
    }

    public static int divide(int numerator, int denominator) {
        if (denominator == 0) {
            // Throw an ArithmeticException if the denominator is zero.
            throw new ArithmeticException("Division by zero");
        }
        return numerator / denominator;

	}

}
