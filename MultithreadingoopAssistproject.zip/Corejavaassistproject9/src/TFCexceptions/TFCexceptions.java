package TFCexceptions;

class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

public class TFCexceptions {

	public static void main(String[] args) {
		try {
            // 1. Throwing a built-in exception (ArithmeticException)
            int result = divide(5, 0);

            // 2. Throwing a custom exception
            if (result == 0) {
                throw new CustomException("Division by zero is not allowed");
            }

            // 3. Normal code execution if no exceptions are thrown
            System.out.println("Result of division: " + result);
        } 
		catch (ArithmeticException e) {
            System.out.println("ArithmeticException: " + e.getMessage());
        }
		catch (CustomException e) {
            System.out.println("CustomException: " + e.getMessage());
        }
		finally {
            System.out.println("Finally block executed");
        }
    }

    public static int divide(int a, int b) {
        // 5. Throwing an ArithmeticException if b is 0
        if (b == 0) {
            throw new ArithmeticException("Division by zero");
        }
        return a / b;
    }
}