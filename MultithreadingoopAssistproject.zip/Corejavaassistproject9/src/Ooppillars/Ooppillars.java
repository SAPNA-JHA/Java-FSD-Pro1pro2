package Ooppillars;


		// Define a class representing a Person
		class Person {
		    // Attributes
		    private String name;
		    private int age;

		    // Constructor
		    public Person(String name, int age) {
		        this.name = name;
		        this.age = age;
		    }

		    // Encapsulation: Getter and Setter methods
		    public String getName() {
		        return name;
		    }

		    public void setName(String name) {
		        this.name = name;
		    }

		    public int getAge() {
		        return age;
		    }

		    public void setAge(int age) {
		        if (age >= 0) {
		            this.age = age;
		        } else {
		            System.out.println("Age cannot be negative.");
		        }
		    }

		    // Abstraction: Display information about the Person
		    public void displayInfo() {
		        System.out.println("Name: " + name);
		        System.out.println("Age: " + age);
		    }
		}

		// Inheritance: Create a Student class that inherits from Person
		class Student extends Person {
		    private String student_Id;

		    public Student(String name, int age, String studentId) {
		        super(name, age);
		        this.student_Id = student_Id;
		    }

		    public String getStudentId() {
		        return student_Id;
		    }

		    public void setStudentId(String studentId) {
		        this.student_Id = student_Id;
		    }

		    // Polymorphism: Override the displayInfo method to provide specific information for Student
		    @Override
		    public void displayInfo() {
		        super.displayInfo();
		        System.out.println("Student ID: " + student_Id);
		    }
		}

		public class Ooppillars {

			public static void main(String[] args) {
		        // Creating objects of Person and Student classes
		        Person person = new Person("Jenny", 30);
		        Student student = new Student("Sapna", 30, "12355");

		        // Using objects and demonstrating the pillars of OOP
		        System.out.println("Information about a Person:");
		        person.displayInfo();
		        System.out.println("\nInformation about a Student:");
		        student.displayInfo();

		        // Encapsulation: Setting age to a negative value
		        person.setAge(-5);

		        // Polymorphism: Using a Person reference to refer to a Student object
		        Person personStudent = new Student("Charles", 32, "67810");
		        System.out.println("\nInformation about a Student using a Person reference:");
		        personStudent.displayInfo();
		    }


	}
