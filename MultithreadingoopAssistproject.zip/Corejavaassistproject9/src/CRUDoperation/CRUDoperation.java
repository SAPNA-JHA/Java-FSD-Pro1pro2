package CRUDoperation;
import java.io.*;

public class CRUDoperation {

	public static void main(String[] args) {
		        // Create a file
		        String fileName = "sample.txt";
		        createFile(fileName);

		        // Read the file
		        readFile(fileName);

		        // Update the file
		        updateFile(fileName, "Updated content.");


		        // Delete the file
		        deleteFile(fileName);
		    }

		    // Create a new file
		    public static void createFile(String fileName) {
		        try {
		            File file = new File(fileName);

		            if (file.createNewFile()) {
		                System.out.println("File created: " + file.getName());
		            } else {
		                System.out.println("File already exists.");
		            }
		        } catch (IOException e) {
		            System.err.println("An error occurred while creating the file: " + e.getMessage());
		        }
		    }

		    // Read the content of a file
		    public static void readFile(String fileName) {
		        try {
		            FileReader fileReader = new FileReader(fileName);
		            BufferedReader bufferedReader = new BufferedReader(fileReader);

		            String line;
		            System.out.println("File content:");
		            while ((line = bufferedReader.readLine()) != null) {
		                System.out.println(line);
		            }

		            bufferedReader.close();
		        } catch (FileNotFoundException e) {
		            System.err.println("File not found: " + e.getMessage());
		        } catch (IOException e) {
		            System.err.println("An error occurred while reading the file: " + e.getMessage());
		        }
		    }

		    // Update the content of a file
		    public static void updateFile(String fileName, String content) {
		        try {
		            FileWriter fileWriter = new FileWriter(fileName);
		            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

		            bufferedWriter.write(content);

		            bufferedWriter.close();
		            System.out.println("File updated.");
		        } catch (IOException e) {
		            System.err.println("An error occurred while updating the file: " + e.getMessage());
		        }
		    }

		    // Delete a file
		    public static void deleteFile(String fileName) {
		        File file = new File(fileName);
		        if (file.delete()) {
		            System.out.println("File deleted: " + file.getName());
		        } else {
		            System.err.println("Failed to delete the file.");
		        }
		    }


	}
