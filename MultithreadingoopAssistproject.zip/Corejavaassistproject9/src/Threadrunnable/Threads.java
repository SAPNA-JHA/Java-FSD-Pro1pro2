package Threadrunnable;
class MyThread extends Thread {
    public void run() {
        for (int i = 1; i <= 7; i++) {
            System.out.println("Thread (extending Thread): " + i);
            try {
                Thread.sleep(3000); // Sleep for 3 second
            } catch (InterruptedException e) {
                System.err.println(" interrupted thread.");
            }
        }
    }
}

public class Threads {

	public static void main(String[] args) {
		MyThread thread1 = new MyThread();
        thread1.start(); // Start the thread

        // Main thread
        for (int i = 1; i <= 7; i++) {
            System.out.println("Main Thread: " + i);
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                System.err.println(" Thread interrupted.");
            }
        }

	}

}
