package Diamond;
//Create a common interface
interface Animal {
 void eat();
 void sleep();
}

//Create two classes implementing the Animal interface
class Dog implements Animal {

 public void eat() {
     System.out.println("Dog eats All thing.");
 }


 public void sleep() {
     System.out.println("Dog sleeps in a kennel.");
 }
}

class Cat implements Animal {

 public void eat() {
     System.out.println("Cat eats fish.");
 }

 
 public void sleep() {
     System.out.println("Cat sleeps on a cozy bed.");
 }
}

//Create a class that inherits from both Dog and Cat classes
class PetAnimal implements Animal {
 private Dog dog;
 private Cat cat;

 public PetAnimal() {
     this.dog = new Dog();
     this.cat = new Cat();
 }


 public void eat() {
     dog.eat();
     cat.eat();
 }

 public void sleep() {
     dog.sleep();
     cat.sleep();
 }
}


public class Diamond {

	public static void main(String[] args) {
		PetAnimal pet = new PetAnimal();
	     
	     System.out.println("PetAnimal does:");
	     pet.eat();
	     pet.sleep();
		

	}

}
