package Sleepwait;

public class DSW {
	    private static Object LOCK = new Object();
	    public static void main(String args[]) 
	    throws InterruptedException
	    {
	        Thread.sleep(3000);
	        System.out.println("Thread 1 is going to sleep for 3 seconds");
	        synchronized (LOCK) 
	        {
	            LOCK.wait(3000);
	            System.out.println("Thread 1 has woken up after sleeping");
	        }
	    }
	}
