package Fourthsmallest;
import java.util.Arrays;

public class Unsortedlist {
	 public static int findfourthSmallest(int[] arr) {
		  if (arr.length < 4) {
	            System.out.println("List has less than 4 elements.");
	            return -1;
	        }

	        // Sort the array in ascending order
	        Arrays.sort(arr);

	        // The fourth smallest element is at index 3 (0-based indexing)
	        return arr[3];
	    }

	    public static void main(String[] args) {
	        int[] unsortedList = {10, 17, 8, 2, 9, 4,5, 12, 1};
	        int fourthSmallest = findfourthSmallest(unsortedList);

	        if (fourthSmallest != -1) {
	            System.out.println("The fourth smallest element is: " + fourthSmallest);
	        }
	    }
	 }
