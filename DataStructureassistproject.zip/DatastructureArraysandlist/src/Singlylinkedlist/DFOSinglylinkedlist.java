package Singlylinkedlist;
class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    Node head;

    public LinkedList() {
        this.head = null;
    }

    // Insert a new node at the end of the list
    public void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // Delete the first occurrence of a key
    public void delete(int key) {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        if (head.data == key) {
            head = head.next; // Update head to skip the first node
            return;
        }

        Node current = head;
        Node previous = null;

        while (current != null && current.data != key) {
            previous = current;
            current = current.next;
        }

        if (current == null) {
            System.out.println("Key not found in the list.");
        } else {
            previous.next = current.next; // Delete the node
        }
    }

    // Display the linked list
    public void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " -> ");
            current = current.next;
        }
        System.out.println("null");
    }
}


public class DFOSinglylinkedlist {

	public static void main(String[] args) {
		// Insert elements into the linked list
		 LinkedList list = new LinkedList();
        list.insert(20);
        list.insert(24);
        list.insert(30);
        list.insert(43);

        System.out.println("Original Linked List:");
        list.display();

        // Delete the first occurrence of a key (e.g., 20)
        int keyToDelete = 3;
        list.delete(keyToDelete);

        System.out.println("Linked List after deleting " + keyToDelete + ":");
        list.display();

	}

}
