package InsertRemoveQueue;
import java.util.LinkedList;
import java.util.Queue;

public class InsertRemoveQueue {

	public static void main(String[] args) {
		Queue<Integer> queue = new LinkedList<>();
		
		// Enqueue (insert) elements into the queue
        queue.offer(7);
        queue.offer(5);
        queue.offer(8);
        queue.offer(12);

        System.out.println("Queue after enqueuing elements: " + queue);
        
         //  (remove) elements from the queue
        
        int removedElement = queue.poll(); // Removes and returns element
        System.out.println("Removed element: " + removedElement);
        System.out.println("Queue after dequeuing an element: " + queue);
        
        // Peek at the front element without removing it
        
        int frontElement = queue.peek();
        System.out.println("Front element without removal: " + frontElement);

        // Size of the queue
        
        int size = queue.size();
        System.out.println("Size of the queue: " + size);

        // Check if the queue is empty
        
        boolean isEmpty = queue.isEmpty();
        System.out.println("Is the queue empty? " + isEmpty);

	}

}
