package InsertRemoveStack;
import java.util.Stack;

public class InsertRemoveStack {

	public static void main(String[] args) {
		Stack<Integer> stack = new Stack<>();
		
		// Push (insert) elements into the stack
        stack.push(7);
        stack.push(10);
        stack.push(12);
        stack.push(32);

        System.out.println("Stack after pushing elements: " + stack);
        
     // Pop (remove) elements from the stack
        int poppedElement = stack.pop(); // Removes and returns the top element
        System.out.println("Popped element: " + poppedElement);

        System.out.println("Stack after popping an element: " + stack);

        // Peek at the top element without removing it
        int topElement = stack.peek();
        System.out.println("Top element without removal: " + topElement);

        // Size of the stack
        int size = stack.size();
        System.out.println("Size of the stack: " + size);

        // Check if the stack is empty
        boolean isEmpty = stack.isEmpty();
        System.out.println("Is the stack empty? " + isEmpty);

	}

}
