package Rightrotatearray;

public class Rightrotatearray {
    public static void main(String[] args) {
        int[] Array = {11, 22, 33, 44, 56, 66, 75, 85, 99, 88};

        int rotateSteps = 5;
        int length = Array.length;

        // Create a new array to store the rotated elements
        int[] rotatedArray = new int[length];

      
        for (int i = 0; i < rotateSteps; i++) {
            rotatedArray[i] = Array[length - rotateSteps + i];
        }

      
        for (int i = rotateSteps; i < length; i++) {
            rotatedArray[i] = Array[i - rotateSteps];
        }

        // Print the rotated array
        System.out.println("main Array:");
        printArray(Array);

        System.out.println("Rotated Array:");
        printArray(rotatedArray);
    }

    
    public static void printArray(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }
}
