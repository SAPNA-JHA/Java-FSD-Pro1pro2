package Soretdcircularlinkedlist;
class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class SortedCircularLinkedList {
    Node head;

    public SortedCircularLinkedList() {
        head = null;
    }

    // Function to insert a new element into a sorted circular linked list
    public void insert(int data) {
        Node newNode = new Node(data);

        // If the list is empty, make the new node the head and point it to itself
        if (head == null) {
            newNode.next = newNode;
            head = newNode;
            return;
        }

        Node current = head;
        Node prev = null;

        // Traverse the list to find the correct position to insert the new node
        do {
            prev = current;
            current = current.next;

            // If the new element is smaller than the current element, insert it here
            if (data <= current.data) {
                prev.next = newNode;
                newNode.next = current;
                return;
            }

            // If we've reached the head again, it means the new element is the largest,
            // so insert it at the end of the list
        } while (current != head);

        // If the new element is the largest, insert it at the end
        prev.next = newNode;
        newNode.next = head;
    }

    // Function to print the circular linked list
    public void printList() {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }

        Node current = head;

        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);

        System.out.println();
    }
}

public class Soretdcircularlinkedlist {
    public static void main(String[] args) {
        SortedCircularLinkedList list = new SortedCircularLinkedList();
        list.insert(9);
        list.insert(0);
        list.insert(5);
        list.insert(8);

        System.out.println("Sorted Circular Linked List:");
        list.printList();
    }
}